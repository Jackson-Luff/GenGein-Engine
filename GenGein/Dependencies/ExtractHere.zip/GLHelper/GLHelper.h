#pragma once

namespace GL_DEBUG_HELP {

class GLHelpers
{
public:
	static void TurnOnDebugLogging();
private:
	GLHelpers() {}; // Abstract class
};

}